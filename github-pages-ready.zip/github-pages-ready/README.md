# GitHub Pages 上載教學

呢個資料夾已經可以直接 upload 去 GitHub Pages。

## 檔案內容
- `index.html`：主頁，iPhone Safari 可直接打開

## 上載步驟

1. 登入 GitHub，按右上角 `+` → `New repository`
2. Repository name 例如：`account-ledger`
3. 選 `Public`
4. 按 `Create repository`
5. 入到 repo 後按 `Add file` → `Upload files`
6. 將 `index.html` 拖入去
7. 按 `Commit changes`
8. 去 `Settings` → `Pages`
9. 在 `Build and deployment`：
   - Source 選 `Deploy from a branch`
   - Branch 選 `main`
   - Folder 選 `/ (root)`
10. 按 `Save`
11. 等 1-3 分鐘，GitHub 會顯示網站網址，例如：
   `https://你的帳號.github.io/account-ledger/`
12. 用 iPhone Safari 打開上面條網址
13. 如果想似 app 咁快開：Safari 分享按鈕 → `Add to Home Screen`

## 注意
- 呢個網站仍然會讀取你而家設定嘅 Google Apps Script URL 去同步 Google Sheet
- 如果 Apps Script 權限或部署有改，HTML 入面嘅 API URL 亦要相應更新
- 如果網站未即刻出現，等幾分鐘再 refresh 一次
